const products = [
    {
        name: 'Bicicleta montaña',
        image: './public/jpg/bicicleta.jpg', // modificar por la ruta donde guarden sus imagenes
        price: 200,
        quantity: 2,
    },
    {
        name: 'Iphone 7',
        image: './public/jpg/celular.jpg', // modificar por la ruta donde guarden sus imagenes
        price: 500,
        quantity: 4,
    },
    {
        name: 'Gafas de sol',
        image: './public/jpg/lentes.jpg', // modificar por la ruta donde guarden sus imagenes
        price: 100,
        quantity: 6,
    },
    {
        name: 'Juego comedor',
        image: './public/jpg/mesa.jpg', // modificar por la ruta donde guarden sus imagenes
        price: 320,
        quantity: 1,
    }
];


var list = products.map(function(product){
    return '<tr>' +
                '<td>' + '<img src="' + product.image + '" alt="img" width="100px" height="80px"></img>' + '</td>' +
                '<td>' + product.name + '</td>' +
                '<td>' + product.price + '</td>' +
                '<td>' + product.quantity + '</td>' +
                '<td>' + product.quantity * product.price + '</td>' +
            '</tr>'
})
document.getElementById("products").innerHTML = list;

